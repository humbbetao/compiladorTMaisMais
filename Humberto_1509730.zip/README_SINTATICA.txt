Como executar a sintatica:

	python3 parser.py codigo.tpp

